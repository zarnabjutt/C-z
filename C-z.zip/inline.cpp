#include<iostream>
using namespace std;
inline void displaymessage()
{
    cout<<"Hello world";
}
int main()
{
    displaymessage();
    return 0;
}