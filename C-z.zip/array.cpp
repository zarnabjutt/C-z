#include<iostream>
using namespace std;
int main()
{
    string name="jello World";
    cout<<name<<endl;
    name[0]='H';
    cout<<name[0];
    cout<<name<<endl;
    // cout<<name.at(0);
    return 0;
}