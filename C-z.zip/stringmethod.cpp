#include<iostream>
using namespace std;
int main()
{
    string firstname="Hello";
    string secondname="World";

    cout<<firstname.append(secondname)<<endl;
    // cout<<"The txt size is::"<<txt.size()<<endl;
    // cout<<"The txt length is"<<txt.length()-1;
    return 0;
}