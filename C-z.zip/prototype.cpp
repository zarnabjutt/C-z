#include<iostream>
using namespace std;
void area(int b)
{
    cout<<b;
};
int main()
{
    int b=7;
    area(b);
    return 0;
}