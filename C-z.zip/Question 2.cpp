#include<iostream>
using namespace std;
int main()
{
	int r,b;
	cout<<"Enter Length=";
	cin>>r;
	cout<<"Enter breadth=";
	cin>>b;
	if(r==b)
	{
		cout<<"it is a square"<<endl;
	}
	else
	{
		cout<<"it is a rectangular"<<endl;
	}
}
