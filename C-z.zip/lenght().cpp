#include<iostream>
using namespace std;
int main()
{
    string s="Hello World!";
    cout<<"this area is length is "s.length();
    return 0;
}