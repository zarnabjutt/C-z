#include<iostream>
using namespace std;
void choice(int b)
{
	cout<<b<<endl;
}
int main()
{
	int b=7;
	choice(b);
}
