#include<iostream>
using namespace std; 
int main()
{
	int x=11,y=3;
	cout<<(x%y)<<endl; 
	return 0;
}

