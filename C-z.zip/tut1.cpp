#include<iostream>
using namespace std;
void greet(int a)
{
    cout<<"Hello world";
}
int main()
{
    int a;
    cout<<"Enter any integer";
    cin>>a;
    greet(a);
    return 0;
}
