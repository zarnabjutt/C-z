#include<iostream>
using namespace std;
int main()
{
    char str[100];

    cout<<"Enter a strng::";
    cin>>str;
    cout<<"you have enterd"<<str<<endl;

    // cout<<"\n Enter another string";
    // cin>>str;
    // cout<<"you have enterd second string"<<str<<endl;
    return 0;
}