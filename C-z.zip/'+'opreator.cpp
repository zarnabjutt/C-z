#include<iostream>
using namespace std;
int main()
{
    string s1,s2,s3,s4;
    s1="Hello";
    s2="World!";
    s3=s1+s2;
    s4=s1+" "+s2;
    cout<<s3<<endl;
    cout<<s4;
    return 0;
}