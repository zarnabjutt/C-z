#include<iostream>
using namespace std;
int main()
{
	int e;
		cout<<"Enter the number";
	cin>>e;
	while(e<=20)
	{
		cout<<e<<endl;
		e +=2;
	}
	
	return 0;
}
