#include<iostream>
using namespace std;
int main()
{
    int n=10;
    do
	{
        cout<<n<<endl;
        n--;
    }
   while(n>=1);
    return 0;
}
