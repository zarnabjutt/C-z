#include<iostream>
#include<string>
using namespace std;
int main()
{
     string x="10";
     string y="20";
     string z=x+y;
     cout<<"the sum is::"<<z;
     string firstname ="hello";
     string secondname="World";
     string fullname=firstname+""+secondname;
     cout<<fullname;
     string name="Hello world";
     cout<<name;
    return 0;
}
