#include<iostream>
using namespace std; 
int main(){
	int x=3,y=5;
	(x>y)?cout<<"x is greater":cout<<"y is greater"<<endl;

	return 0;
}

