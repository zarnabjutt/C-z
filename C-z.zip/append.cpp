#include<iostream>
using namespace std;
int main()
{
    string str="soft";
    cout<<"original string: "<<str<<endl;
    str.append("ware");
    cout<<"string after appending: "<<str<<endl;
    return 0;
}