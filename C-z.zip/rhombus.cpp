#include<iostream>
using namespace std;
int main()
{
    int d1,d2;
    float area;
    cout<<"Enter the first diagonal of the rhombus: ";
    cin>>d1>>d2;
    area=(d1*d2)/2;
    cout<<"The area of the rhombus is: "<<area;
    return 0;
}