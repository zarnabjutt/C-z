#include<iostream>
using namespace std;
int main()
{
    float s;
    cout<<"Enter the side of the square: ";
    cin>>s;
    float area=s*s;
    cout<<"The area of the square is: "<<area;
    return 0;
}