#include<iostream>
using namespace std; 
int main()
{
	int x;
	cout<<"Enter Value of x="<<x;
	cin>>x;
	cout<<"value of x ="<<x;
	return 0;
}
