#include<iostream>
using namespace std;
void greet()
{
	cout<<"Hello world";
};
int main()
{
	greet();
	return 0;
}
