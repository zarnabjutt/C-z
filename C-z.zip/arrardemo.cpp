#include<iostream>
using namespace std;
int main()
{
    int aa[5]={1,2,3,4,5};
    int i;
    cout<<"Content of the array: ";
    for(int i=0;i<5;i++)
    {
        cout<<aa[i]<<" ";
    }
}