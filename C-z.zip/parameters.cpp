// function without parameter
#include<iostream>
using namespace std;
void greet()
{
    cout<<"Hello, World!"<<endl;
}
int main()
{
    greet();
    return 0;
}
